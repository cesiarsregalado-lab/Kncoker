package com.obsessedknocker;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;

/** Cliente mínimo para la API de mensajes de Anthropic (Claude). Devuelve null si falla o no hay API key. */
public final class AiClient {
    private static final HttpClient HTTP = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(10))
            .build();
    private static final Map<UUID, Deque<JsonObject>> HISTORY = new ConcurrentHashMap<>();
    private static final int MAX_HISTORY = 12;

    public static boolean hasKey() {
        return !KnockerConfig.get().resolveApiKey().isEmpty();
    }

    public static CompletableFuture<String> ask(UUID playerId, String userText) {
        KnockerConfig cfg = KnockerConfig.get();
        String key = cfg.resolveApiKey();
        if (key.isEmpty()) return CompletableFuture.completedFuture(null);

        Deque<JsonObject> hist = HISTORY.computeIfAbsent(playerId, k -> new ArrayDeque<>());
        JsonObject userMsg = message("user", userText);
        List<JsonObject> snapshot;
        synchronized (hist) {
            hist.addLast(userMsg);
            while (hist.size() > MAX_HISTORY) hist.removeFirst();
            while (!hist.isEmpty() && !"user".equals(hist.peekFirst().get("role").getAsString())) hist.removeFirst();
            snapshot = new ArrayList<>(hist);
        }

        JsonObject body = new JsonObject();
        body.addProperty("model", cfg.model);
        body.addProperty("max_tokens", cfg.maxTokens);
        body.addProperty("system", cfg.systemPrompt);
        JsonArray msgs = new JsonArray();
        snapshot.forEach(msgs::add);
        body.add("messages", msgs);

        HttpRequest request = HttpRequest.newBuilder(URI.create(cfg.endpoint))
                .timeout(Duration.ofSeconds(30))
                .header("content-type", "application/json")
                .header("x-api-key", key)
                .header("anthropic-version", "2023-06-01")
                .POST(HttpRequest.BodyPublishers.ofString(body.toString()))
                .build();

        return HTTP.sendAsync(request, HttpResponse.BodyHandlers.ofString())
                .thenApply(resp -> {
                    if (resp.statusCode() / 100 != 2) {
                        ObsessedKnocker.LOGGER.warn("Error de la API de IA ({}): {}", resp.statusCode(), resp.body());
                        forget(hist, userMsg);
                        return (String) null;
                    }
                    String text = extractText(resp.body());
                    if (text == null || text.isBlank()) {
                        forget(hist, userMsg);
                        return null;
                    }
                    text = text.trim();
                    synchronized (hist) {
                        hist.addLast(message("assistant", text));
                    }
                    return text;
                })
                .exceptionally(ex -> {
                    ObsessedKnocker.LOGGER.warn("Fallo al llamar a la IA: {}", ex.toString());
                    forget(hist, userMsg);
                    return null;
                });
    }

    private static void forget(Deque<JsonObject> hist, JsonObject msg) {
        synchronized (hist) {
            hist.removeLastOccurrence(msg);
        }
    }

    private static JsonObject message(String role, String text) {
        JsonObject o = new JsonObject();
        o.addProperty("role", role);
        o.addProperty("content", text);
        return o;
    }

    private static String extractText(String json) {
        try {
            JsonObject root = JsonParser.parseString(json).getAsJsonObject();
            JsonArray content = root.getAsJsonArray("content");
            StringBuilder sb = new StringBuilder();
            for (JsonElement el : content) {
                JsonObject block = el.getAsJsonObject();
                if (block.has("type") && "text".equals(block.get("type").getAsString())) {
                    sb.append(block.get("text").getAsString());
                }
            }
            return sb.toString();
        } catch (RuntimeException e) {
            ObsessedKnocker.LOGGER.warn("Respuesta de IA ilegible: {}", e.toString());
            return null;
        }
    }

    private AiClient() {
    }
}
