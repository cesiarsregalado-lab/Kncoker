package com.obsessedknocker;

import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;

public final class ModSounds {
    public static final SoundEvent IDLE = register("knocker.idle");
    public static final SoundEvent SPAWN = register("knocker.spawn");
    public static final SoundEvent SCARE = register("knocker.scare");
    public static final SoundEvent BREATH = register("knocker.breath");
    public static final SoundEvent WHISTLE = register("knocker.whistle");
    public static final SoundEvent SAY_DOOR = register("knocker.say_door");
    public static final SoundEvent SAY_WINDOW = register("knocker.say_window");

    private static SoundEvent register(String name) {
        Identifier id = Identifier.of(ObsessedKnocker.MOD_ID, name);
        return Registry.register(Registries.SOUND_EVENT, id, SoundEvent.of(id));
    }

    public static void init() {
    }

    private ModSounds() {
    }
}
