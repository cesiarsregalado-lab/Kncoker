package com.obsessedknocker.entity;

import com.obsessedknocker.AiClient;
import com.obsessedknocker.KnockerConfig;
import com.obsessedknocker.ModSounds;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvent;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.world.World;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.UUID;

public class KnockerEntity extends PathAwareEntity {
    private static final String GLITCH = "#%&?!/\\|<>*@";
    private static final int CHARS_EVERY_TICKS = 2;   // velocidad de "escritura"
    private static final int HOLD_TICKS = 50;         // cuánto queda visible el texto completo

    private record Line(UUID playerId, String text) {
    }

    private final ArrayDeque<Line> queue = new ArrayDeque<>();
    private Line current;
    private int shown;
    private int hold;

    private int nextLineTimer;
    private int nextBreathTimer;

    public KnockerEntity(EntityType<? extends PathAwareEntity> type, World world) {
        super(type, world);
        this.setPersistent();
        this.nextLineTimer = randomLineDelay();
        this.nextBreathTimer = 100 + this.random.nextInt(200);
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return MobEntity.createMobAttributes()
                .add(EntityAttributes.MAX_HEALTH, 40.0)
                .add(EntityAttributes.MOVEMENT_SPEED, 0.32)
                .add(EntityAttributes.FOLLOW_RANGE, 48.0);
    }

    // ------------------------------------------------------------------ IA / Goals

    @Override
    protected void initGoals() {
        this.goalSelector.add(0, new SwimGoal(this));
        this.goalSelector.add(1, new FollowPlayerGoal(this));
        this.goalSelector.add(2, new LookAtEntityGoal(this, PlayerEntity.class, 16.0f));
        this.goalSelector.add(3, new LookAroundGoal(this));
    }

    /** Te sigue cuando te alejas unos bloques. */
    private static class FollowPlayerGoal extends Goal {
        private final KnockerEntity mob;
        private PlayerEntity target;
        private int recalc;

        FollowPlayerGoal(KnockerEntity mob) {
            this.mob = mob;
            this.setControls(EnumSet.of(Goal.Control.MOVE, Goal.Control.LOOK));
        }

        @Override
        public boolean canStart() {
            PlayerEntity p = mob.getWorld().getClosestPlayer(mob, 48.0);
            if (p == null || p.isSpectator() || !p.isAlive()) return false;
            double start = KnockerConfig.get().followStartDistance;
            if (mob.squaredDistanceTo(p) <= start * start) return false;
            this.target = p;
            return true;
        }

        @Override
        public boolean shouldContinue() {
            if (target == null || !target.isAlive() || target.isSpectator()) return false;
            double stop = KnockerConfig.get().followStopDistance;
            return mob.squaredDistanceTo(target) > stop * stop;
        }

        @Override
        public void start() {
            recalc = 0;
        }

        @Override
        public void stop() {
            target = null;
            mob.getNavigation().stop();
        }

        @Override
        public void tick() {
            mob.getLookControl().lookAt(target, 30.0f, 30.0f);
            if (--recalc <= 0) {
                recalc = 8;
                double speed = mob.squaredDistanceTo(target) > 144.0 ? 1.5 : 1.1;
                mob.getNavigation().startMovingTo(target, speed);
            }
        }
    }

    // ------------------------------------------------------------------ Sonidos

    @Override
    protected SoundEvent getAmbientSound() {
        return ModSounds.BREATH;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return ModSounds.IDLE;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return ModSounds.SCARE;
    }

    // ------------------------------------------------------------------ Tick

    @Override
    public void tick() {
        super.tick();
        if (this.getWorld().isClient()) return;

        if (this.age == 2) this.playSound(ModSounds.SPAWN, 1.0f, 1.0f);

        if (--nextBreathTimer <= 0) {
            nextBreathTimer = 160 + this.random.nextInt(280);
            this.playSound(this.random.nextInt(4) == 0 ? ModSounds.WHISTLE : ModSounds.BREATH, 1.0f, 1.0f);
        }

        // Textos espontáneos aunque no le hables
        if (--nextLineTimer <= 0) {
            nextLineTimer = randomLineDelay();
            PlayerEntity p = this.getWorld().getClosestPlayer(this, KnockerConfig.get().spontaneousRadius);
            if (p instanceof ServerPlayerEntity sp && current == null && queue.isEmpty()) {
                List<String> lines = KnockerConfig.get().lines;
                if (!lines.isEmpty()) {
                    say(sp.getUuid(), lines.get(this.random.nextInt(lines.size())));
                }
            }
        }

        tickText();
    }

    private int randomLineDelay() {
        KnockerConfig c = KnockerConfig.get();
        int min = Math.max(20, c.spontaneousMinTicks);
        int max = Math.max(min + 1, c.spontaneousMaxTicks);
        return min + this.random.nextInt(max - min);
    }

    // ------------------------------------------------------------------ Texto animado

    /** Encola un texto: se "escribe" letra a letra en la barra de acción con glitch y luego queda en el chat. */
    public void say(UUID playerId, String text) {
        for (String chunk : splitChunks(text)) {
            queue.add(new Line(playerId, chunk));
        }
        // Voz: susurro de puerta / ventana / silbido
        int r = this.random.nextInt(10);
        this.playSound(r < 5 ? ModSounds.SAY_DOOR : r < 8 ? ModSounds.SAY_WINDOW : ModSounds.WHISTLE, 1.0f, 1.0f);
    }

    private void tickText() {
        if (current == null) {
            current = queue.poll();
            if (current == null) return;
            shown = 0;
            hold = 0;
        }
        MinecraftServer server = ((ServerWorld) this.getWorld()).getServer();
        ServerPlayerEntity p = server.getPlayerManager().getPlayer(current.playerId());
        if (p == null) {
            current = null;
            return;
        }

        String full = current.text();
        if (shown < full.length()) {
            if (this.age % CHARS_EVERY_TICKS == 0) shown++;
            MutableText t = Text.literal(full.substring(0, shown)).formatted(Formatting.DARK_RED, Formatting.ITALIC);
            if (shown < full.length()) {
                char g = GLITCH.charAt(this.random.nextInt(GLITCH.length()));
                t.append(Text.literal(String.valueOf(g)).formatted(Formatting.RED, Formatting.OBFUSCATED));
            }
            p.sendMessage(t, true);
        } else {
            hold++;
            if (hold == 1) {
                p.sendMessage(Text.literal(full).formatted(Formatting.RED, Formatting.ITALIC), true);
                p.sendMessage(Text.literal("<Knocker> ").formatted(Formatting.DARK_RED)
                        .append(Text.literal(full).formatted(Formatting.RED, Formatting.ITALIC)), false);
            }
            if (hold > HOLD_TICKS) current = null;
        }
    }

    private static List<String> splitChunks(String text) {
        List<String> out = new ArrayList<>();
        for (String sentence : text.trim().split("(?<=[.!?…])\\s+")) {
            String s = sentence.trim();
            while (s.length() > 90) {
                int cut = s.lastIndexOf(' ', 90);
                if (cut < 20) cut = 90;
                out.add(s.substring(0, cut).trim());
                s = s.substring(cut).trim();
            }
            if (!s.isEmpty()) out.add(s);
        }
        return out;
    }

    // ------------------------------------------------------------------ Chat con IA

    public void onPlayerSaid(ServerPlayerEntity player, String message) {
        UUID id = player.getUuid();
        MinecraftServer server = ((ServerWorld) this.getWorld()).getServer();

        this.getLookControl().lookAt(player, 60.0f, 60.0f);
        this.playSound(ModSounds.BREATH, 1.0f, 1.0f);
        nextLineTimer = Math.max(nextLineTimer, 400); // no se pisa con un texto espontáneo

        if (!AiClient.hasKey()) {
            player.sendMessage(Text.literal("[Knocker] Falta la API key en config/obsessedknocker.json (o variable ANTHROPIC_API_KEY).")
                    .formatted(Formatting.GRAY), false);
        }

        AiClient.ask(id, message).thenAccept(reply -> server.execute(() -> {
            if (this.isRemoved()) return;
            String out = reply;
            if (out == null) {
                List<String> lines = KnockerConfig.get().lines;
                out = lines.isEmpty() ? "..." : lines.get(this.random.nextInt(lines.size()));
            }
            say(id, out);
        }));
    }
}
