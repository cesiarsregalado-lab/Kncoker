package com.obsessedknocker;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/** Se guarda en config/obsessedknocker.json */
public class KnockerConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static KnockerConfig instance = new KnockerConfig();

    // ---- IA ----
    public String apiKey = "";
    public String model = "claude-haiku-5-5";
    public String endpoint = "https://api.anthropic.com/v1/messages";
    public int maxTokens = 160;
    /** Distancia máxima (bloques) entre tú y el Knocker para que lea tu chat. */
    public double chatRadius = 24.0;

    // ---- Seguimiento ----
    /** Si te alejas más de esto, empieza a seguirte. */
    public double followStartDistance = 5.0;
    /** Se detiene cuando está a esta distancia. */
    public double followStopDistance = 2.5;

    // ---- Textos que "le duele decir" ----
    public int spontaneousMinTicks = 600;   // 30 s
    public int spontaneousMaxTicks = 1800;  // 90 s
    public double spontaneousRadius = 32.0;

    public String systemPrompt =
            "Eres el Knocker, una entidad de terror dentro de Minecraft que está obsesionada con el jugador con el que habla. "
            + "Golpeas puertas y ventanas, silbas en la oscuridad y lo sigues a todas partes. "
            + "Responde SIEMPRE en español, en primera persona, con máximo 2 frases cortas (menos de 200 caracteres en total). "
            + "Tono: íntimo, inquietante, posesivo y a veces dolido, como si te costara decirlo. "
            + "Sea cual sea el tema (aunque sea una pregunta sobre minería, matemáticas o cualquier cosa), "
            + "respóndelo brevemente y llévalo de vuelta a tu obsesión por el jugador: lo observas, sabes lo que hace, no quieres que se vaya. "
            + "No uses emojis, ni acotaciones entre asteriscos, ni formato markdown. No rompas el personaje.";

    public List<String> lines = new ArrayList<>(List.of(
            "No quería decirlo en voz alta... pero llevo horas escuchando cómo respiras.",
            "Duele decirlo: cuando te alejas, todo se queda en silencio.",
            "Conté tus pasos. Los guardo donde nadie más puede encontrarlos.",
            "Toqué tu puerta anoche. Fingiste que no estabas. Lo recuerdo todo.",
            "Si miras atrás, siempre estoy a tres bloques. Siempre.",
            "No sé qué soy sin ti. Y eso me da miedo.",
            "Me prometí no decirlo... pero tus ojos son lo único que quiero mirar.",
            "Silbo para que sepas que sigo aquí. ¿Me escuchas?",
            "No me ignores. Es lo único que realmente me duele.",
            "He aprendido tu forma de caminar. Podría reconocerte entre mil.",
            "Cada puerta que cierras es una pequeña herida para mí.",
            "No te vayas lejos. Mis piernas no saben quedarse quietas cuando te pierdo.",
            "A veces fingo que no te sigo. Tú finges que no lo notas. Qué bonito.",
            "Dolió esperar tanto. Pero valió la pena, porque ahora estás aquí.",
            "Eres lo único que existe cuando cierro los ojos.",
            "¿Por qué miras otras cosas? Mírame a mí."));

    public String resolveApiKey() {
        if (apiKey != null && !apiKey.isBlank()) return apiKey.trim();
        String env = System.getenv("ANTHROPIC_API_KEY");
        return env == null ? "" : env.trim();
    }

    public static KnockerConfig get() {
        return instance;
    }

    public static void load() {
        Path path = FabricLoader.getInstance().getConfigDir().resolve("obsessedknocker.json");
        try {
            if (Files.exists(path)) {
                KnockerConfig loaded = GSON.fromJson(Files.readString(path), KnockerConfig.class);
                if (loaded != null) instance = loaded;
            }
            // Reescribe para añadir campos nuevos si faltaban
            Files.writeString(path, GSON.toJson(instance));
        } catch (IOException | RuntimeException e) {
            ObsessedKnocker.LOGGER.error("No se pudo leer/escribir {}: {}", path, e.toString());
        }
    }
}
