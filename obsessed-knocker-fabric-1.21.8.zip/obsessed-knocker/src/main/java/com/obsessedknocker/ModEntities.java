package com.obsessedknocker;

import com.obsessedknocker.entity.KnockerEntity;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;

public final class ModEntities {
    public static final RegistryKey<EntityType<?>> KNOCKER_KEY =
            RegistryKey.of(RegistryKeys.ENTITY_TYPE, Identifier.of(ObsessedKnocker.MOD_ID, "knocker"));

    public static final EntityType<KnockerEntity> KNOCKER = Registry.register(
            Registries.ENTITY_TYPE,
            KNOCKER_KEY,
            EntityType.Builder.create(KnockerEntity::new, SpawnGroup.CREATURE)
                    .dimensions(0.6f, 1.8f)
                    .maxTrackingRange(10)
                    .build(KNOCKER_KEY));

    public static void init() {
        FabricDefaultAttributeRegistry.register(KNOCKER, KnockerEntity.createAttributes());
    }

    private ModEntities() {
    }
}
