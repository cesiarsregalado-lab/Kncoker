package com.obsessedknocker;

import com.obsessedknocker.entity.KnockerEntity;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.message.v1.ServerMessageEvents;
import net.minecraft.network.message.MessageType;
import net.minecraft.network.message.SignedMessage;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Comparator;
import java.util.List;

public class ObsessedKnocker implements ModInitializer {
    public static final String MOD_ID = "obsessedknocker";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        KnockerConfig.load();
        ModSounds.init();
        ModEntities.init();
        ServerMessageEvents.CHAT_MESSAGE.register(ObsessedKnocker::onChat);
    }

    /** Cuando un jugador escribe en el chat, el Knocker más cercano (dentro del radio) le responde con IA. */
    private static void onChat(SignedMessage message, ServerPlayerEntity sender, MessageType.Parameters params) {
        String text = message.getSignedContent();
        if (text == null || text.isBlank()) return;

        ServerWorld world = (ServerWorld) sender.getWorld();
        double r = KnockerConfig.get().chatRadius;
        List<KnockerEntity> near = world.getEntitiesByClass(
                KnockerEntity.class, sender.getBoundingBox().expand(r), k -> k.isAlive());
        near.stream()
                .min(Comparator.comparingDouble(k -> k.squaredDistanceTo(sender)))
                .ifPresent(k -> k.onPlayerSaid(sender, text));
    }
}
