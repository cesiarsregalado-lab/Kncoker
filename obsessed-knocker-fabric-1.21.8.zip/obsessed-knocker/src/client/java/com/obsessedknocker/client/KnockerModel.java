package com.obsessedknocker.client;

import com.obsessedknocker.ObsessedKnocker;
import net.minecraft.client.model.Dilation;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.render.entity.state.BipedEntityRenderState;
import net.minecraft.util.Identifier;

/** Modelo humanoide con capas de skin (64x64, brazos clásicos), igual que el addon original. */
public class KnockerModel extends BipedEntityModel<BipedEntityRenderState> {
    public static final EntityModelLayer LAYER =
            new EntityModelLayer(Identifier.of(ObsessedKnocker.MOD_ID, "knocker"), "main");

    private final ModelPart jacket;
    private final ModelPart leftSleeve;
    private final ModelPart rightSleeve;
    private final ModelPart leftPants;
    private final ModelPart rightPants;

    public KnockerModel(ModelPart root) {
        super(root);
        this.jacket = root.getChild("jacket");
        this.leftSleeve = root.getChild("left_sleeve");
        this.rightSleeve = root.getChild("right_sleeve");
        this.leftPants = root.getChild("left_pants");
        this.rightPants = root.getChild("right_pants");
        if (root.hasChild("ear")) root.getChild("ear").visible = false;
        if (root.hasChild("cloak")) root.getChild("cloak").visible = false;
    }

    public static TexturedModelData getTexturedModelData() {
        ModelData data = PlayerEntityModel.getTexturedModelData(Dilation.NONE, false);
        return TexturedModelData.of(data, 64, 64);
    }

    @Override
    public void setAngles(BipedEntityRenderState state) {
        super.setAngles(state);
        this.leftPants.copyTransform(this.leftLeg);
        this.rightPants.copyTransform(this.rightLeg);
        this.leftSleeve.copyTransform(this.leftArm);
        this.rightSleeve.copyTransform(this.rightArm);
        this.jacket.copyTransform(this.body);
    }
}
