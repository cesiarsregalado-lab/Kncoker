package com.obsessedknocker.client;

import com.obsessedknocker.ObsessedKnocker;
import com.obsessedknocker.entity.KnockerEntity;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.render.entity.state.BipedEntityRenderState;
import net.minecraft.util.Identifier;

public class KnockerRenderer extends MobEntityRenderer<KnockerEntity, BipedEntityRenderState, KnockerModel> {
    private static final Identifier TEXTURE =
            Identifier.of(ObsessedKnocker.MOD_ID, "textures/entity/knocker.png");

    public KnockerRenderer(EntityRendererFactory.Context context) {
        super(context, new KnockerModel(context.getPart(KnockerModel.LAYER)), 0.5f);
    }

    @Override
    public Identifier getTexture(BipedEntityRenderState state) {
        return TEXTURE;
    }

    @Override
    public BipedEntityRenderState createRenderState() {
        return new BipedEntityRenderState();
    }
}
