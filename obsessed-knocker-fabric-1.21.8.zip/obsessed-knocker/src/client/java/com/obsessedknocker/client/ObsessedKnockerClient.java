package com.obsessedknocker.client;

import com.obsessedknocker.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;

public class ObsessedKnockerClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        EntityModelLayerRegistry.registerModelLayer(KnockerModel.LAYER, KnockerModel::getTexturedModelData);
        EntityRendererRegistry.register(ModEntities.KNOCKER, KnockerRenderer::new);
    }
}
