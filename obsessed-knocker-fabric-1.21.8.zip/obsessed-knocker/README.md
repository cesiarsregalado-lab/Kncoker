# Knocker Obsessed (Fabric 1.21.8)

## Compilar
Necesitas Java 21. Copia el `gradle/wrapper` + `gradlew` de la plantilla de https://fabricmc.net/develop
(o ten Gradle 8.14+ instalado) y ejecuta:

    gradle build

El .jar queda en `build/libs/`.

## IA
Al iniciar por primera vez se crea `config/obsessedknocker.json`. Pon tu clave en `apiKey`
(o define la variable de entorno `ANTHROPIC_API_KEY`). Modelo por defecto: `claude-haiku-5-5`.

## Uso
- `/summon obsessedknocker:knocker` (con trucos activados)
- Escribe en el chat a menos de 24 bloques: te responde con IA.
- Si te alejas más de 5 bloques te sigue.
- Cada 30-90 s te dice un texto por su cuenta (editable en `lines`).
